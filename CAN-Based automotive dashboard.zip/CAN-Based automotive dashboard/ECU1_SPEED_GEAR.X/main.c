/*
 * File:   main.c
 * Author: VAISHNAVI
 *
 * Created on 28 October, 2025, 11:26 AM
 */


#include <xc.h>
#include "adc.h"
#include "clcd.h"
#include "mkp.h"
#include "can.h"
#include "sensor.h"
#include "msg_id.h"
#include "uart.h"

static void init_config(void)
{
    //init_clcd();

    init_adc();
    //init_matrix_keypad();
    init_digital_keypad();
    init_can();
    
  
}
unsigned int index = 0;
unsigned char speed[3];



unsigned int msg_id;
unsigned int len;
unsigned char data[5];
void main(void) {
     init_config();
    while(1)
    {
       //clcd_print("SPEED  GEAR",LINE1(0));
      // init_speed();
        get_speed();
       
//       can_receive(&msg_id,data,&len);
//       data[2] = '\0';
//       if(msg_id == SPEED_MSG_ID)
//       {
//          
//           clcd_print(data,LINE2(0));
//       }
       //init_gear();
        get_gear_pos();
//       can_receive(&msg_id,data,&len);
//       data[2] = '\0';
//       if(msg_id == GEAR_MSG_ID)
//       {
//           
//           clcd_print(data,LINE2(8));
//       }
    }
    return;
}
