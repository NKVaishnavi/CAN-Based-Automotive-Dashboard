
#include<xc.h>
#include "sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "mkp.h"
#include "dkp.h"

unsigned int index = 0;
unsigned char speed[3];
  unsigned char event[9][3] = {"ON","GN","G1","G2","G3","G4","G5","GR","C_"};
    unsigned char key;
uint16_t get_speed()
{
    // Implement the speed function
    unsigned int speed1;
    
    
        speed1 = read_adc(CHANNEL4)/10.33;
        
        speed[0] = speed1 / 10 + '0'; 
        speed[1] = speed1 % 10 + '0'; 
        speed[2] = '\0';
       can_transmit(SPEED_MSG_ID,speed,2);
       for(unsigned int delay = 1000;delay--;);
       
      
}

unsigned char get_gear_pos() 
{
     //Implement the gear function
    key = read_digital_keypad(STATE_CHANGE);
   
    if(key == SWITCH1)
    { 
        if(index == 8)
       index = 0;
        if(index < 7)
        index++;
    }
    else if(key == SWITCH2)
    {
        if(index == 8)
       index = 2;
        if(index > 1 )
        index--;
    }
    else if(key == SWITCH3)
    {
        index = 8 ;
       
    }
    
    //clcd_print((event[index]),LINE2(8));
    can_transmit(GEAR_MSG_ID,event[index],2);
    
    for(unsigned int delay = 1000;delay--;);
    
    
}