#include <xc.h>
#include "adc.h"
//#include "clcd.h"
#include "dkp.h"
#include "can.h"
#include "sensor.h"
#include "msg_id.h"
#include "uart.h"
unsigned int rpm;
unsigned int rpm_value;
unsigned char key;
unsigned char key_value;
unsigned int left_flag;
unsigned char data[5];
unsigned char indicator[3];
unsigned int right_flag;
unsigned int len;
unsigned int len1;
unsigned int msg_id;
unsigned int indicator_msg;
//static unsigned char ssd[MAX_SSD_CNT];
//static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
void main()
{
    //call the functions
    init_adc();
    init_digital_keypad();
    //init_ssd_control();
    //init_clcd();
    init_can();
//    PORTB = 0X00;
//    TRISB = 0X00;
    GIE = 1;
    PEIE = 1;
    ADCON1 = 0x0F;
    T08BIT = 1;
	T0CS = 0;
	PSA = 1;
	TMR0 = 6;
	TMR0IF = 0;
	TMR0IE = 1;
    TMR0ON = 1;
    
    while(1)
    {
      
        get_rpm();
        
        process_indicator();
        

    }
    
}