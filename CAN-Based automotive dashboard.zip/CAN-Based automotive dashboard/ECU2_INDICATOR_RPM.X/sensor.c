

#include<xc.h>
#include "sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "dkp.h"


extern unsigned int rpm;
extern unsigned char key;
extern unsigned int left_flag;
extern unsigned int right_flag;
unsigned char indicator[3];
unsigned int msg_id;
unsigned int len;
unsigned char data[5];
uint16_t get_rpm()
{
    //Implement the rpm function
    rpm = ((read_adc(CHANNEL4))/10.23)*60;
     // rpm_value = get_rpm();
        unsigned int temp = rpm;
        for(int i = 3;i>=0;i--)
       {
            data[i] = (temp%10)+'0';
            temp = temp/10;
        }
        data[4] = '\0';
        
        can_transmit(RPM_MSG_ID,data,4);
        for(unsigned int i = 1000;i--;);
//        can_receive(&msg_id,data,&len);
//        ssd[0] = digit[data[0] - '0'];
//        ssd[1] = digit[data[1] - '0'];
//        ssd[2] = digit[data[2] - '0'];
//        ssd[3] = digit[data[3] - '0'];
        //display(ssd);
//        data[4] = '\0';
//        clcd_print(data,LINE2(0));
        
    //return rpm;
    
}
IndicatorStatus process_indicator()
{
     key = read_digital_keypad(STATE_CHANGE);
        if(key == SWITCH1)
        {
            left_flag = 1;
            right_flag = 0;
        }
        else if(key == SWITCH3)
        {
            right_flag = 1;
            left_flag = 0;
        }
        else if(key == SWITCH2)
        {
            right_flag = 0;
            left_flag = 0;
            
        }
        indicator[0] = left_flag + 48;
        indicator[1] = right_flag + 48;
        indicator[2] = '\0';
        can_transmit(INDICATOR_MSG_ID,indicator,3);
        for(unsigned int i = 1000;i--;);
}
uint16_t get_engine_temp()
{
    //Implement the engine temperature function
}


