#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"
#include "uart.h"


//volatile unsigned char led_state = LED_OFF, status = e_ind_off;

//IndicatorStatus status = e_ind_off;
unsigned int right_flag;
unsigned int left_flag;
void handle_speed_data(uint8_t *data, uint8_t len) 
{
    //Implement the speed function
    clcd_print("S_P",LINE1(0));
    data[2] = '\0';
    clcd_print(data,LINE2(0));
     
    
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    //Implement the gear function
    clcd_print("G_R",LINE1(4));
    data[2] = '\0';
    clcd_print(data,LINE2(4));
    
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    //Implement the rpm function
    data[4] = '\0';
    clcd_print("RPM_",LINE1(8));
    clcd_print(data,LINE2(8));
}

//void handle_engine_temp_data(uint8_t *data, uint8_t len) 
//{
//    //Implement the temperature function
//}
//
void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    //Implement the indicator function
    clcd_print("IND",LINE1(13));
    //        can_receive(&indicator_msg,indicator,&len1);
        left_flag = data[0] - 48;
        right_flag = data[1] - 48;
        if(left_flag == 1)
        {
            clcd_print("<-",LINE2(13));
        }
        else if(right_flag == 1)
        {
            clcd_print("->",LINE2(13));
        }
        else if(left_flag == 0 && right_flag == 0)
        {
            clcd_print("OFF",LINE2(13 ));
        }
        
}
void __interrupt() isr(void)
{
	static unsigned short count;
     
	if (TMR0IF)
	{
    if(left_flag)
    {
       RIGHT_IND_OFF();
       
         if(count++ == 20000)
            {
             count = 0;
             LEFT_IND_OFF();
            }
            else if(count == 10000)
            {
                LEFT_IND_ON();
            }
        }
        else if(right_flag)
        {
           
           LEFT_IND_OFF();
            if(count++ == 20000)
            {
                RIGHT_IND_OFF();
                count = 0;
            }
            else if(count == 10000)
            {
                
                RIGHT_IND_ON();
            }
        }
        else
        {
            RIGHT_IND_OFF();
            LEFT_IND_OFF();
        }
		TMR0IF = 0;
	}
}

void process_canbus_data() 
{   
    //process the CAN bus data
    unsigned char msg_id;
    unsigned int len;
    unsigned char data[8];
    can_receive(&msg_id,data,&len);
    //data[4] = '\0';
    switch(msg_id)
    {
         case SPEED_MSG_ID:
                           
                          handle_speed_data(data,len);
                          break;
                          
          case GEAR_MSG_ID:
                         handle_gear_data(data,len);
                          break;
                          
           case RPM_MSG_ID:
                           handle_rpm_data(data,len);
                          break;
                          
           case INDICATOR_MSG_ID:
                          handle_indicator_data(data,len);
                          break;      
//           
//           case ENG_TEMP_MSG_ID:
//                           handle_engine_temp_data(data,len);
//                           break;
                          
            default:
                         // Unknown message
                          break;              
    }                   
    
}
